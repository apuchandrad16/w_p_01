$(document).ready(function(){

    let $btns = $('.project__area .button__group button');

    $btns.click(function(e){

        $('.project__area .button__group button').removeClass('active');
        e.target.classList.add('active');

        let selector = $(e.target).attr('data-filter');
        $('.project__area .grid').isotope({
            filter: selector
        });

        return false;
    });

    $('#btn_1').trigger('click')

    $('.grid .test-popup-link').magnificPopup({
        type:'image',
        gallery:{enabled:true}
    });

    // owl-carusol

    $('.about__area .owl-carousel').owlCarousel({
        loop:true,
        autoplay:true,
        dots:true,
        responsive:{
            0:{
                items: 1
            },
            544:{
                items: 2
            }
        }
    })

// stiky navigation menu

let nav_offset_top = $('.header__area').height() + 50;

function navbarFixed(){
    if($('.header__area').length){
        $(window).scroll(function(){
            let scroll = $(window).scrollTop();
            if(scroll>=nav_offset_top){
                $('.header__area .main__menu').addClass('navbar__fixed');
            }else{
                $('.header__area .main__menu').removeClass('navbar__fixed');
            };
        });
    };
};

navbarFixed();

});